#!/bin/bash
./kplc 
./kplrun 